"use strict";

const AWS_LAMBDA_FUNCTION_NAME = process.env.AWS_LAMBDA_FUNCTION_NAME

exports.handler = (event, context) => {
  console.log(`PLACEHOLDER LAMBDA RUNNING for service: ${AWS_LAMBDA_FUNCTION_NAME}`)
  console.log('call `yarn start` in each lambda you wish to run locally');
};
